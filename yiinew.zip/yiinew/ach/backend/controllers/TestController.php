<?php
namespace backend\controllers;
use Yii;
use yii\web\Controller;
use common\libs\curl;


class TestController extends Controller{
	public $enableCsrfValidation = false;
	public function actionIndex(){

		return $this->render('first');

	}
	public function actionLook()
	{
		header("content-type:text/html;charset=utf-8");
		$sql = 'select count(1) count from title';
		$count = Yii::$app->db->createCommand($sql)->queryOne();
		//  var_dump($data);die;

		$p = Yii::$app->request->get('p');//当前页
		$p = $p ? $p : 1;

		$limit = ($p-1)*2;//偏移量
		$sql = 'select * from title limit '.$limit.',2';//分页 ，每页显示两条
		$data['data'] = Yii::$app->db->createCommand($sql)->queryAll();//以数组的形

		return $this->render('index',$data);
	}
	public function actionExam(){
		if (Yii::$app->request->isPost) 
		{
			
			// var_dump($_FILES);die;
			$dir = '/phpstudy/www/yiinew/ach/backend/upload/excel.xls';
			$reg = move_uploaded_file($_FILES['excel']['tmp_name'],$dir);
			if ($reg) 
			{
				header("content-type:text/html;charset=utf-8");
				$url = 'http://47.94.210.163/yiinew/ach/api/web/index.php?r=test/index';
				$param['month'] = Yii::$app->request->post('month');
				$param['unit'] = Yii::$app->request->post('unit');
				$file['excel']=$dir;

				$reg = curl::_post($url,$param,$file);
				// var_dump($param);die;
				if ($reg) 
				{
					echo $reg;die;
				}
			}
		}
		else
		{
			return $this->render('exam');
		}
	}
	public function actionOnline_exam(){
		header("content-type:text/html;charset=utf8");
		$sql ="select * from title inner join answer on title.id = answer.id";
		$data['data'] = Yii::$app->db->createCommand($sql)->queryAll();
		// var_dump($data);die;
		return $this->render('exam_do',$data);
	}
	public function actionMyscore()
	{
		return $this->render('myscore');
	}
	public function actionData_exam(){

	}



	
}

?>