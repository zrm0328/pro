<form action="exam_do_submit" method="post" action="index.php?r=test/data_exam">


<table class="table table-striped">
	
	<thead>
		<tr>
			<th>所学单元</th>
			<th>类型</th>
			<th>题目</th>
			<th>选项</th>
			
		</tr>
	</thead>
	
	<tbody>
		<?php foreach($data as $val){?>
		<tr>
			<td><?=$val['unit']?></td>
			<td><?php if($val['type']=='p-1') echo '1-单选('.$val['score'].')'?>
				<?php if($val['type']=='p-2') echo '2-多选('.$val['score'].')'?>
				<?php if($val['type']=='p-0') echo '0-判断('.$val['score'].')'?>
			</td>
			<td><?=$val['id']?>.<?=$val['subject']?></td>
		 	<td>
			<?php if ($val['type'] == 'p-1') 
			{
				echo '<input type="radio">'.$val['option'];
			}?>
			<?php if ($val['type'] == 'p-2') 
			{
				echo '<input type="checkbox">'.$val['option'];
			}?>
			<?php if ($val['type'] == 'p-0') 
			{
				echo '<input type="radio">'."正确".'<input type="radio">'."错误";
			}
			?>
			</td>
		</tr>
		<?php }?>
	</tbody>
	
</table>
	<button type="button" class="btn btn-danger">提交</button>
</form>


