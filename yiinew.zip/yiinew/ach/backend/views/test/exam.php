<form role="form" action="index.php?r=test/exam" method="post" enctype="multipart/form-data">
		<div class="form-group">
		<label for="name">所选月份</label>
		<select name="month">
			<?php foreach (Yii::$app->params['month'] as $key => $value) {?>
			<option value="<?=$key?>"><?=$value?></option>
		<?php }?>
		</select>
	</div>
	<div class="form-group">
		<label for="name">所选单元</label>
		<select name="unit">
			<?php foreach (Yii::$app->params['unit'] as $key => $value) {?>
			<option value="<?=$key?>"><?=$value?></option>
		<?php }?>
		</select>
	</div>
	<div class="form-group">
		<label for="inputfile">文件输入</label>
		<input type="file" id="inputfile" name="excel">
	</div>
	<button type="submit" class="btn btn-default">提交</button>
</form>