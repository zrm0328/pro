<ul class="breadcrumb">
	<li><a href="index.php?r=test/index">主页</a></li>
	<li><a href="index.php?r=test/online_exam">在线考试</a></li>
	<li><a href="index.php?r=test/myscore">我的成绩</a></li>
	<li><a href="index.php?r=test/look">查看试题</a></li>
	<a href="index.php?r=test/exam" title="" style="float: right">试题导入</a>
</ul>

<table class="table table-striped">
	
	<thead>
		<tr>
			<th>考试题目</th>
			<th>所学月份</th>
			<th>所学单元</th>
			<th>类型</th>
			<th>考试时间</th>
			<th>出题人</th>
			<th>该分值</th>
			<th>操作</th>
		</tr>
	</thead>
	
	<tbody>
		<?php foreach($data as $val){?>
		<tr id="$val['id']">
			<td><?=$val['subject']?></td>
			<td><?=$val['month']?></td>
			<td><?=$val['unit']?></td>
			<td><?php if($val['type']=='p-1') echo '1-单选';?>
				<?php if($val['type']=='p-2') echo '2-多选';?>
				<?php if($val['type']=='p-0') echo '0-判断';?>
			</td>
			<td><?=date('Y-m-d H:m:s',$val['add_time'])?></td>
			<td><?=$val['subject_person']?></td>
			<td><?=$val['score']?></td>
			<td><a href="javascript:void(0)" class="del">删除</a></td>
		</tr>
		<?php }?>
	</tbody>
	
</table>
<div id="page">
	<?=$page;?>
</div>

<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
<script>
	var obj =new Object();//全局变量

	//分页
	$(document).on('click','.page',function(){
		var p = $(this).attr('atr');
		getdata(p);
	})
	//删除

	$(document).on('click','.del',function(){
		var id = $(this).parents('tr').attr('id');
		obj['id'] = id;
		getdata(obj['p'],'del');
	})
	//搜索
	$('#btn').click(function(){
		$("#from :input").each(function(k,v){
			if($(v).attr('name') != undefined) 
			{
				obj[$(v).attr('name')] = $(v).val();
			}
		})
		getdata(1);
		// console.log(obj);
	})
	//封装分页
	function getdata(p,fun ='getdata')
	{
		obj['p']=p;//把p放到obj中 ，为了与搜索一起使用 ，是为了只是覆盖页数，并不是所有的数据
		$.ajax({
			url:'index.php?r=test/'+fun,
			data:obj, //数据
			dataType:'json',
			success:function(msg){
				var str = ''; //定义一个空的字符串
				$.each(msg.data,function(k,v){//循环想要的数据
						str += '<tr id="'+v.id+'">';//拼接数据
						str += '<td>'+v.subject+'</td>'
						str += '<td>'+v.month+'</td>'
						str += '<td>'+v.unit+'</td>'
						str += '<td>'+v.type+'</td>'
						str += '<td>'+v.add_time+'</td>'

						str += '<td>'+v.subject_person+'</td>'
						str += '<td>'+v.score+'</td>'

						str += '<td><a href="javascript:void(0)" class="del">删除</a></td>'
						str += '</tr>'
				})
				$('tbody').html(str);//把身体里的数据送到网页上
				$('#page').html(msg.page);
			}

		})
	}
</script>