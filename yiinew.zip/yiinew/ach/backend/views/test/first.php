<ul class="breadcrumb">
	<li><a href="index.php?r=test/index">主页</a></li>
	<li><a href="index.php?r=test/online_exam">在线考试</a></li>
	<li><a href="index.php?r=test/myscore">我的成绩</a></li>
	<li><a href="index.php?r=test/look">查看试题</a></li>
	<a href="index.php?r=test/exam" title="" style="float: right">试题导入</a>
</ul>



