<?php
namespace frontend\controllers;
use Yii;
use yii\web\Controller;
use common\libs\curl;


class TestController extends Controller{
	public $enableCsrfValidation = false;
	public function actionIndex(){
		return $this->render('index');
	}
	public function actionIndex_do()
	{
		header("content-type:text/html;charset=utf8");
		$get = Yii::$app->request->get();
		$where = ' 1=1 AND ';
		foreach ($get['unit'] as $key => $val) 
		{
			$where .="(month=".$key;
			$ids = implode(",",$val);
			$where .=' AND  unit in('.$ids.')) OR ';
		}
		$where = substr($where,0,strlen($where)-3);

		$sql = "select * from answer join (select * from title where type='p-1' and ((month=11 and unit in(5)) or (month=12 and unit in(4))) limit 20) as title on answer.id = title.id order by rand()";
		$dx = Yii::$app->db->createCommand($sql)->queryAll();
		$sql = "select * from answer join (select * from title where type='p-2' and ((month=11 and unit in(5)) or (month=12 and unit in(4))) limit 10) as title on answer.id = title.id order by rand()";
		$dxs = Yii::$app->db->createCommand($sql)->queryAll();
		$sql = "select * from answer join (select * from title where type='p-0' and ((month=11 and unit in(5)) or (month=12 and unit in(4))) limit 10) as title on answer.id = title.id order by rand()";
		$pd = Yii::$app->db->createCommand($sql)->queryAll();
		$arr = array_merge($dx,$dxs,$pd);
		foreach ($arr as $key => $val) 
		{
			if (!isset($data[$val['id']])) {
				$data[$val['id']]=$val;
				
			}
			$child = array(
				'id' => $val['id'],
				'option' => $val['option'],

			);
			$data[$val['id']]['answer'][]=$child;

		}
		// var_dump($data);die;
		return $this->render('index_do',['data'=>$data]);
	
	}
}