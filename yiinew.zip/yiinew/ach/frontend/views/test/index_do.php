<form action="exam_do_submit" method="post" action="index.php?r=test/data_exam">


<table class="table table-striped">
	
	<thead>
		<tr>
			<th>类型</th>
			<th>题目</th>
			<th>选项</th>
			
		</tr>
	</thead>
	
	<tbody>
		<?php foreach($data as $key=>$val){?>
		<tr>
			<td><?=$key;?>.<?=Yii::$app->params['type'][$val['type']]?></td>
			<td><?=$val['subject']?></td>
			<?php foreach ($val['answer'] as $k => $v) {?>
				<td><?=$v['option']?></td>
			<?php }?>
		</tr>
		<?php }?>
	</tbody>
	
</table>
	<button type="button" class="btn btn-danger">提交</button>
</form>


