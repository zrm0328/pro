<form action="index.php?r=test/index_do" method="get" accept-charset="utf-8">
	<input type="hidden" name="r" value="test/index_do">
<?php foreach (Yii::$app->params['month'] as $key => $value) {?>
	<input type="checkbox"><?=$value?> <br>
	<?php foreach (Yii::$app->params['unit'] as $k => $v) {?>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="unit[<?=$key;?>][]" value="<?=$k?>"><?=$v;?> <br>
	<?php }?>
<?php }?>

<input type="submit" value="提交">
</form>